package Programa;

public abstract class AtaquesEstado extends Ataque{

	public AtaquesEstado(String nombre, String tipo, int potencia, int precision, int pp, boolean prioridad) {
		super(nombre, tipo, 0, precision, pp, prioridad);
		// TODO Auto-generated constructor stub
	}
}
